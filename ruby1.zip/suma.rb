puts 1 + 2
